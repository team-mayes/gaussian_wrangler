import os

a = os.path.dirname(os.path.abspath(__file__))
print(a)
